/**
 * 
 
I'd be happy to share a bit about myself 

I have overall 13 years of IT experience

I worked on Single page application with responsive web designing, using Polymer JS, Angular JS, Bootstrap, Material design.

I have good experience in creating dynamic and responsive web applications by consuming backend service apis.




I'm well-versed with state management with services and observables, and integrating with various backend systems using APIs. 

Throughout my career, I've had the privilege of working on a diverse range of projects, from small startups to large enterprises, which has given me a broad perspective on the challenges and opportunities that come with web development.

I pride myself on writing clean, maintainable, and modular code that follows best practices. 

In addition to my technical skills, I've also gained valuable experience in collaborating with designers, product managers, and other stakeholders to deliver successful projects that meet both user needs and business goals.

As the Angular ecosystem is constantly evolving, I make a point to stay up-to-date with the latest updates, tools, and practices. 

 */