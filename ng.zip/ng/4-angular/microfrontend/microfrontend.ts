/*

//install @angular/elements package and import
//remove the bootstrap from @ngModule()
//app module add ngDoBootStrap() and inside the method createCustomElement and pass the component which you wants make it mfe also pass the injector
//customeElements.define give the mfe name and pass the element
//"bundle": "ng build --output-hashing none && node concat.js"

import { Injector, NgModule } from '@angular/core';
import { createCustomElement } from '@angular/elements';
import { BrowserModule } from '@angular/platform-browser';

import { AppComponent } from './app.component';

@NgModule({
  declarations: [AppComponent],
  imports: [BrowserModule],
  providers: [],
})
export class AppModule {
  constructor(private injector: Injector) {}

  ngDoBootstrap() {
    const element = createCustomElement(AppComponent, {
      injector: this.injector,
    });
    customElements.define('app-micro-fe', element);
  }
}

*/