/*
OAuth (Open Authorization) is an authentication and authorization framework that allows third-party applications to access user data from a resource server (such as a social media platform, cloud service, or API) on behalf of the user. OAuth is widely used to provide secure access to protected resources without requiring the third-party application to know the user's credentials, like their username and password.

Here's how OAuth works in a simplified manner:

Generally there are 4 Roles:

Resource Owner: who owns the data (like google) 
Client: The third-party application that wants to access the user's data.
Authorization Server: The server responsible for authenticating the user and issuing access tokens.
Resource Server: The server hosting the user's protected resources (data) that the client wants to access.

Authorization Flow:
The OAuth flow typically involves several steps:

a. Authorization Request:

The client initiates the process by redirecting the user to the authorization server's authentication page.
The client includes its identity (client ID) and the requested scope (the level of access it wants) in the request.

b. User Authentication and Consent:

The user logs in to the authorization server (if not already authenticated) and is presented with the scope of access requested by the client.
The user grants or denies permission to the client.

c. Authorization Grant:

If the user grants permission, the authorization server generates an authorization code or access token, depending on the OAuth version.

d. Token Exchange:

The client exchanges the authorization code (or other credentials) with the authorization server for an access token.
This access token is a credential that represents the client's permission to access the user's resources.

e. Access Resources:

The client uses the access token to make requests to the resource server on behalf of the user.
The resource server validates the token and grants access to the requested resources if the token is valid and has the necessary permissions.

Access Tokens:

Access tokens are short-lived credentials that grant the client access to specific resources. They are typically associated with an expiration time and are used in API requests to prove the client's authorization.

Refresh Tokens:

Some OAuth flows also provide refresh tokens. These tokens can be used by the client to obtain new access tokens without requiring the user's involvement. Refresh tokens are useful for maintaining long-term access to resources.

OAuth supports different grant types (authorization flows) based on the level of security required and the application's needs. The most common grant types are Authorization Code Grant, Implicit Grant, Resource Owner Password Credentials Grant, and Client Credentials Grant.

It's important to note that OAuth primarily focuses on authorization (granting access), not authentication (verifying identity). OAuth 2.0 has been the most widely adopted version, but it's important to implement it securely and understand the specifics of the OAuth flow you're using, as well as the security implications for your application.

*/