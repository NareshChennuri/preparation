/** 
 * 
 * Below are the main differences between reactive forms and template driven forms

Feature	                                Reactive	                                                        Template-Driven

Form model setup	                    Created(FormControl instance) in component explicitly	            Created by directives
Data updates	                        Synchronous	                                                        Asynchronous
Form custom validation	                Defined as Functions	                                            Defined as Directives
Testing	                                No interaction with change detection cycle	                        Need knowledge of the change detection process
Mutability	                            Immutable(by always returning new value for FormControl instance)	Mutable(Property always modified to new value)
Scalability	                            More scalable using low-level APIs	                                Less scalable using due to abstraction on APIs


*/