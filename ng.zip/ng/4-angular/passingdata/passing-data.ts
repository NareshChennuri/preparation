/** 

Parent child:  Input, Output & Event emitters. ViewChild.

Navigating:  Routing

Global data : Services, Local storage, Temp storage

*/

import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';

@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.css']
})
export class HeaderComponent implements OnInit {

  constructor() { }

  @Input() headerTitle: string;
  @Output() navOut = new EventEmitter();
  @Output() setLoggedInFlag = new EventEmitter();

  loginLabel = 'login';

  onNavLink(linkName: string) {
    if (linkName === 'logout') {
      this.loginLabel = 'login';
      this.setLoggedInFlag.emit(false);
    } else if (linkName === 'login') {
      this.loginLabel = 'logout';
      this.setLoggedInFlag.emit(true);
    }
    this.navOut.emit(linkName);
  }

  ngOnInit() {
  }

}

/*** app-component */

import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'angular-communication';
  linkName: string;

  loginFlag: boolean;

  onNavigation(navLink: string) {
    this.linkName = navLink;
  }

  setLoggedInUser(loggedIn: boolean) {
    this.loginFlag = loggedIn;
  }
}


<!--The content below is only a placeholder and can be replaced.-->
<div style="text-align:center">
  <app-header
    [headerTitle]="title"
    (navOut)="onNavigation($event)"
    (setLoggedInFlag)="setLoggedInUser($event)"
  >
  </app-header>
  <app-welcome></app-welcome>
  <div>
    <h2><span class="page">Page: </span><span class="linkname">{{linkName}}</span></h2>
  </div>
  <div>
      <app-parent></app-parent>
  </div>
  <app-footer
    [isUserLoggedIn]="loginFlag"
  >
  </app-footer>
</div>

<router-outlet></router-outlet>
