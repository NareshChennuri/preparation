/*

Static Typing: TypeScript introduces static typing to JavaScript, allowing developers to specify the types of variables, function parameters, and function return values. This helps catch type-related errors at compile time, leading to more reliable code.

Type Annotations: Developers can use type annotations to explicitly specify the types of variables and functions. For example:

let message: string = "Hello, TypeScript!";
function add(a: number, b: number): number {
    return a + b;
}

Type Inference: TypeScript also supports type inference, where the type of a variable is automatically determined based on its value. This reduces the need for explicit type annotations while still providing type safety.

Interfaces: TypeScript allows you to define interfaces, which describe the shape of objects and provide a way to enforce structure in your code. This is especially useful when working with complex data structures.

Classes and Object-Oriented Programming: TypeScript supports class-based object-oriented programming concepts, including inheritance, encapsulation, and interfaces. It allows you to write more organized and maintainable code using familiar object-oriented patterns.

Enums: Enums in TypeScript provide a way to define a set of named constants with associated numeric values. This makes your code more expressive and easier to understand.

Union and Intersection Types: TypeScript introduces union types that allow variables to hold values of multiple types, and intersection types that combine multiple types into one.

Generics: TypeScript supports generics, allowing you to create reusable components and functions that work with different types. This is particularly useful for writing libraries or functions that can operate on various data types.

Null and Undefined Handling: TypeScript includes stricter null and undefined handling through the use of the null and undefined types. This helps prevent common runtime errors related to null or undefined values.

Decorators: Decorators are a way to add metadata and behavior to classes, methods, properties, or parameters in TypeScript. They are often used in frameworks like Angular for aspects like dependency injection, routing, and more.

Advanced Type Features: TypeScript provides advanced type features like mapped types, conditional types, and template literal types, which allow for powerful type manipulations and transformations.

*/