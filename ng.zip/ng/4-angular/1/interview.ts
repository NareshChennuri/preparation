/*

#### Decorators 

are a design pattern or functions that define how Angular features work. They are used to make prior modifications to a class, service, or filter. Angular supports four types of decorators, they are:

Class Decorators
Property Decorators
Method Decorators
Parameter Decorators


#### angular advantages

MVC architecture - Angular is a full-fledged MVC framework. 

Modularity 

different design patterns like components, directives, pipes, and services

Dependency injection: Components dependent on other components can be easily worked around using this feature. 

Other generic advantages include clean and maintainable code, unit testing, reusable components, data binding, and excellent responsive experience.



### The Ahead-of-time (AOT) compiler 

converts the Angular HTML and TypeScript code into JavaScript code during the build phase, 
i.e., before the browser downloads and runs the code.

Some of its advantages are as follows. 

Faster rendering
Fewer asynchronous requests
Smaller Angular framework download size
Quick detection of template errors
Better security



#### Ahead of Time (AOT) compilation 
converts your code during the build time before the browser downloads and runs that code. This ensures faster rendering to the browser. To specify AOT compilation, include the --aot option with the ng build or ng serve command. 

#### The Just-in-Time (JIT) compilation 
process is a way of compiling computer code to machine code during execution or run time. It is also known as dynamic compilation. JIT compilation is the default when you run the ng build or ng serve CLI commands. 


#### Components 

are the basic building blocks of the user interface in an Angular application. 
Every component is associated with a template and is a subset of directives. 
An Angular application typically consists of a root component, which is the AppComponent, that then branches out into other components creating a hierarchy.


#### View encapsulation 
defines whether the template and styles defined within the component can affect the whole application or vice versa. Angular provides three encapsulation strategies:

Emulated - styles from the main HTML propagate to the component.
Native - styles from the main HTML do not propagate to the component. 
None - styles from the component propagate back to the main HTML and therefore are visible to all components on the page.


*/