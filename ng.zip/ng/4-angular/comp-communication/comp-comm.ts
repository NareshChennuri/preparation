/*


there are several ways to achieve component communication, such as using Input and Output properties, ViewChild/ViewChildren, Services, and RxJS Subjects. Below, I'll provide examples for each of these methods.

Let's assume we have two components: ParentComponent and ChildComponent, and we want to pass data from the parent to the child component.

Using Input and Output Properties:
Parent Component (parent.component.ts):
==================================================
import { Component } from '@angular/core';

@Component({
  selector: 'app-parent',
  template: `
    <app-child [message]="parentMessage" (messageEvent)="receiveMessage($event)"></app-child>
  `,
})
export class ParentComponent {
  parentMessage = "Message from parent";

  receiveMessage($event: string) {
    console.log($event);
  }
}

Child Component (child.component.ts):
===========================================
import { Component, Input, Output, EventEmitter } from '@angular/core';

@Component({
  selector: 'app-child',
  template: `
    <p>{{ message }}</p>
    <button (click)="sendMessage()">Send Message</button>
  `,
})
export class ChildComponent {
  @Input() message: string;
  @Output() messageEvent = new EventEmitter<string>();

  sendMessage() {
    this.messageEvent.emit("Message from child");
  }
}

Using Services:
Shared Service (data.service.ts):
============================================
import { Injectable } from '@angular/core';
import { BehaviorSubject } from 'rxjs';

@Injectable({
  providedIn: 'root',
})
export class DataService {
  private messageSource = new BehaviorSubject<string>("Initial message");
  currentMessage = this.messageSource.asObservable();

  changeMessage(message: string) {
    this.messageSource.next(message);
  }
}
Parent Component (parent.component.ts):
================================================
import { Component } from '@angular/core';
import { DataService } from './data.service';

@Component({
  selector: 'app-parent',
  template: `
    <app-child></app-child>
  `,
})
export class ParentComponent {
  constructor(private dataService: DataService) {}

  sendMessageToChild() {
    this.dataService.changeMessage("Message from parent");
  }
}
Child Component (child.component.ts):
===================================================
import { Component, OnInit } from '@angular/core';
import { DataService } from './data.service';

@Component({
  selector: 'app-child',
  template: `
    <p>{{ message }}</p>
  `,
})
export class ChildComponent implements OnInit {
  message: string;

  constructor(private dataService: DataService) {}

  ngOnInit() {
    this.dataService.currentMessage.subscribe(message => this.message = message);
  }
}


*/