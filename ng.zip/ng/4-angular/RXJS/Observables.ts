/**

OBSERVABLES
-----------

Can be used for Emitting multiple values asynchronously 
Observables are considered lazy, so in case of no subscription there will be no emission of data values
Observables can be resolved multiple times as opposed to functions or promises
Error handling is easy in Observables rather than promises

Use a Observable when…
    you only need one subscriber. 
    Or you don't care that the subscriber that comes first will be finished first 
    until the second will get its values.

    Life Cycles of Observables
    - Creation
    - Subscription
    - Execution
    - Destruction

NOTE:    

An Observable is UNICAST. 
An Observer and its Subscriber have a one-to-one relationship. 
Each subscribed Observer owns an independent execution of the Observable.

With the Observables the data is sent to the first subscriber and will finish before it continues to the next subscriber.
Each call to observable.subscribe triggers its independent setup for that given subscriber.


OBSERVERS
-----------

Observer connects to the Observables with the help of subscription.

observer that subscribes can deliver three values to the Observable

    - next value
    - error value
    - complete value


    const rxjs = require('rxjs');
    const { Observable } = rxjs;
    
    const observable = new Observable(subscriber => {
        subscriber.next(1);
        subscriber.next(2);
        subscriber.next(3);
        subscriber.complete();
    });
    
    console.log('just before subscribe');

    // Subscriber 1
    observable.subscribe({
    next(x) { console.log('sub1: got value ' + x); },
    error(err) { console.error('sub1: something wrong occurred: ' + err); },
    complete() { console.log('sub1: done'); }
    });

    // Subscriber 2
    observable.subscribe({
    next(x) { console.log('sub2: got value ' + x); },
    error(err) { console.error('sub2: something wrong occurred: ' + err); },
    complete() { console.log('sub2: done'); }
    });

    console.log('just after subscribe');

    // Output
    //------------------------
    "just before subscribe"
    "sub1: got value 1"
    "sub1: got value 2"
    "sub1: got value 3"
    "sub1: done"
    "sub2: got value 1"
    "sub2: got value 2"
    "sub2: got value 3"
    "sub2: done"
    "just after subscribe"



With the Observables the data is sent to the first subscriber and will finish before it continues to the next subscriber.
Each call to observable.subscribe triggers its independent setup for that given subscriber.

*/