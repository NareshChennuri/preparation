/**

SUBJECT (MULTICAST)
----------
Subject is useful for broadcasting events to multiple subscribers.

Subject is an observable that can be subscribed to

A Subject has three methods that you can use:

    - subscribe() you can activate the subscription of a new subscriber.
    - next() you can pass new values. All the current subscribers will receive this.
    - complete() you close all the subscriptions to the Subject.


When to use Subject:

    When you need multiple subscribers and all the subscribers needs to get the new values simultaneously, you need a Subject.

    Use a BehaviourSubject when you need initial value & the last given value.

    Use a ReplaySubject when you need more than the last given value (For example, the previous five values). 
        Or you want to set a time window for the values can be validly sent to subscribers.

    Use an AsyncSubject when you only want the last value to be passed to the subscribers.

    Use a Void Subject if you don't want to pass any value but just want to hook into the event.




const rxjs = require('rxjs');
const { Subject } = rxjs;
N
const subject = new Subject();
 
subject.subscribe({
  next: (v) => console.log(`observerA: ${v}`)
});
subject.subscribe({
  next: (v) => console.log(`observerB: ${v}`)
});
 
subject.next(1);
subject.next(2);

// Output

"observerA: 1"
"observerB: 1"
"observerA: 2"
"observerB: 2"


*/