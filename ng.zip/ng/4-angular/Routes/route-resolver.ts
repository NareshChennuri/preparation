/* Route resolver 
Using Route resolver we can only load the page or navigate to the page after getting the http response.

this way we can prevent the partial page loading and also able to display spinner

import { Resolve, ActivatedRouteSnapshot, RouterStateSnapshot } from '@angular/router';
import { Product, productResolved } from './product';
import { Observable, of } from 'rxjs';
import { ProductService } from './product.service';
import { map, catchError } from 'rxjs/operators';
@Injectable({
  providedIn: 'root'
})
export class ProductResolverService implements Resolve<productResolved> {

  constructor(private productdata: ProductService) { }

  resolve(next: ActivatedRouteSnapshot, state: RouterStateSnapshot): Observable<productResolved> {
    return this.productdata.getAllProducts().pipe(
      map(product => ({ product: product, errorMessage: '' })),
      catchError(err => {
        console.log(err);
        return of({ product: null, errorMessage: err.message });
      })
    );
  }
}

/** display the spinner while route is navigating 
import { Component } from "@angular/core";
import { Router, Event, NavigationStart, NavigationEnd, NavigationCancel, NavigationError } from "@angular/router";

@Component({
  selector: "app-root",
  templateUrl: "./app.component.html",
  styleUrls: ["./app.component.css"]
})
export class AppComponent {
  title = "angularRoutingApplication";
  loading = true;

  constructor(private _router: Router) {
    _router.events.subscribe((routerEvent: Event) => {
      this.checkRouterEvent(routerEvent);
    });
  }

  checkRouterEvent(routerEvent: Event): void {
    if (routerEvent instanceof NavigationStart) {
      this.loading = true;
      console.log('router event start');
    }

    if (routerEvent instanceof NavigationEnd ||
      routerEvent instanceof NavigationCancel ||
      routerEvent instanceof NavigationError) {
      console.log('router event finish');
      this.loading = false;
    }
  }
}

*/