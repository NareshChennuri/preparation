/*

Angular 6, 

Ivy Renderer was introduced as an opt-in preview. 
Ivy is a new rendering engine for Angular that aims to provide better performance, smaller bundle sizes, and improved debugging capabilities. 
It eventually became the default rendering engine starting from Angular 9.


AngularJS (Angular 1.x):

AngularJS was the original version of Angular, often referred to as Angular 1.x.
Released in 2010 by Google.
Followed the principles of two-way data binding.

Angular 2:

Released in September 2016.
A complete rewrite of AngularJS, focused on performance, modularity, and improved architecture.
Introduced components, modules, services, and the concept of reactive programming with RxJS.

Angular 4:

Released in March 2017.
Notable improvements in rendering and size reduction for production builds.
Introduced template references, *ngIf and *ngFor syntax, and more.

Angular 5:

Released in November 2017.
Introduced HttpClient as a replacement for HttpModule.
Added support for Progressive Web Apps (PWA) with the introduction of the Angular Service Worker.

Angular 6: **********************

Released in May 2018.
Introduced Angular Elements for creating custom elements.
Upgraded to RxJS 6, offering better performance and a more streamlined API.
Ivy Renderer was introduced as an opt-in preview.

Angular 7:

Released in October 2018.
Introduced improvements in Angular Material and CDK.
Added CLI prompts, virtual scrolling, and more.

Angular 8: //Ivy renderer ******************************

Released in May 2019.
Introduced differential loading for smaller bundles and improved performance.
Added Ivy Renderer as an opt-in feature.

Angular 9:

Released in February 2020.
Ivy Renderer became the default rendering engine.
Improved bundle size and performance.
Introduced updated forms APIs.

Angular 10:

Released in June 2020.
Introduced stricter types and improved TypeScript support.
Improved the Angular CLI.

Angular 11:

Released in November 2020.
Introduced improved loading performance and increased bundle size reduction.
Added stricter types and enhanced the Angular CLI.

Angular 12:

Released in May 2021.
Focused on improving the developer experience.
Introduced strict mode by default, enhancements in the Angular CLI, and more.

Angular 13

Improved performance: Angular 13 includes a number of performance improvements, such as lazy loading of modules and components.
New features for web workers: Angular 13 includes new features for web workers, such as the ability to create and manage web workers from Angular code.
Improved support for TypeScript: Angular 13 includes improved support for TypeScript, such as the ability to use generics with Angular components.
New features for testing: Angular 13 includes new features for testing, such as the ability to use Jest with Angular components.

Angular 14

the features like offline availability, standalone components, strictly typed forms, auto-completion, and extended diagnostics among others.

Angular 15

Improved performance: Angular 15 includes a number of performance improvements, such as lazy loading of modules and components.
New features for web workers: Angular 15 includes new features for web workers, such as the ability to create and manage web workers from Angular code.
Improved support for TypeScript: Angular 15 includes improved support for TypeScript, such as the ability to use generics with Angular types.
New features for testing: Angular 15 includes new features for testing, such as the ability to use Jest with Angular.

*/