/**
 * 
 
DOCTYPE declaration: To declare the HTML document type to instruct the web browser about the markup language.

Advantages of HTML 5-
Cleaner Markup/ Improved Code: It will enable the designers to use cleaner, neater code. 

Elegant forms: It enables the designers to use the fancier forms.

Consistency: More consistency will be seen in terms of HTML to code a web page on one site.

Supports rich media elements: It has an inbuilt capacity to play audio and video to let go of plug-in tags.

Offline Application Cache: It will load the page the user has visited if the user is temporarily offline. 

Uses of semantic HTML-
------------------------------
It helps the search engines to determine the importance and context of web pages. 

It is much easier to read with semantic elements.

It has a greater accessibility.

They offer better user experience.

Refer to the below-metioned table for HTML Semantic elements-

Tags	Elements 
<aside>	It defines some content aside from the content it is placed.
<nav>	Defines a set of navigation links.
<article>	Specifies the independent, self- contained content.
<section>	Represents the section of a document.
<header>	Represents a container for introductory content.
<footer>	Represents a footer for the document.
<main>	Specifies the main page.
<summary>	Specifies the header for the <details> element.
<mark>	Specifies the text that is highlighted.


 */