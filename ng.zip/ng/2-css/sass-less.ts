/*
Sass stands for Syntactically Awesome Stylesheet

Sass is an extension to CSS
Sass reduces repetition of CSS and therefore saves time

Sass lets you use features that do not exist in CSS, like variables, nested rules, mixins, imports, inheritance, built-in functions, and other stuff.

These features make the code more modular, reusable, and easier to maintain. Preprocessors also provide a way to organize stylesheets and generate optimized CSS for production. 

/* define variables for the primary colors 
$primary_1: #a2b9bc;
$primary_2: #b2ad7f;
$primary_3: #878f99;

/* use the variables 
.main-header {
  background-color: $primary_1;
}

.menu-left {
  background-color: $primary_2;
}

.menu-right {
  background-color: $primary_3;
}

A browser does not understand Sass code. Therefore, you will need a Sass pre-processor to convert Sass code into standard CSS.

This process is called transpiling. So, you need to give a transpiler (some kind of program) some Sass code and then get some CSS code back.

---------

The @import directive allows you to include the content of one file in another.

@import "variables";
@import "colors";
@import "reset";

----------

Sass Partials
By default, Sass transpiles all the .scss files directly. However, when you want to import a file, you do not need the file to be transpiled directly.

Sass has a mechanism for this: If you start the filename with an underscore, Sass will not transpile it. Files named this way are called partials in Sass.

So, a partial Sass file is named with a leading underscore:

partials example:
"_colors.scss":

$myPink: #EE82EE;
$myBlue: #4169E1;
$myGreen: #8FBC8F;

@import "colors";

body {
  font-family: Helvetica, sans-serif;
  font-size: 18px;
  color: $myBlue;
}

------------------

The @mixin directive lets you create CSS code that is to be reused throughout the website.

@mixin important-text {
  color: red;
  font-size: 25px;
  font-weight: bold;
  border: 1px solid blue;
}

.danger {
  @include important-text;
  background-color: green;
}

A mixin can also include other mixins:

@mixin special-text {
  @include important-text;
  @include link;
  @include special-border;
}

Mixins accept arguments. This way you can pass variables to a mixin.
It is also possible to define default values for mixin variables:

@mixin bordered($color: blue, $width: 1px) {
  border: $width solid $color;
}

Another good use of a mixin is for vendor prefixes.

@mixin transform($property) {
  -webkit-transform: $property;
  -ms-transform: $property;
  transform: $property;
}

.myBox {
  @include transform(rotate(20deg));
}

------------------

The @extend directive lets you share a set of CSS properties from one selector to another.

.button-basic  {
  border: none;
  padding: 15px 30px;
  text-align: center;
  font-size: 16px;
  cursor: pointer;
}

.button-report  {
  @extend .button-basic;
  background-color: red;
}

--------------

functions

String functions

str-length("Hello world!")
Result: 12

to-lower-case("Hello World!")
Result: "hello world!"

str-slice("Hello world!", 2, 5)
Result: "ello"

Numeric functions

abs(15)
Result: 15
abs(-15)
Result: 15

max(5, 7, 9, 0, -3, -7)
Result: 9

min(5, 7, 9, 0, -3, -7)
Result: -7

random(6)
Result: 4

List functions

join(a b c, d e f)
Result: a b c d e f

length(a b c)
Result: 3

nth(a b c, 3)
Result: c


===============

Both Sass and Less are CSS preprocessors.

Both Sass and Less have very similar features. 
Sass uses Ruby whereas Less uses Javascript. There are syntactical differences, for example, Sass uses $ for variables whereas less uses @.
There are some slightly more subjective differences,


SCSS known as the indented syntax provides a more concise way of writing CSS.

*/