/*

https://yoksel.github.io/flex-cheatsheet/

Flexbox is a powerful layout model in CSS that provides a flexible way to arrange elements within a container. It introduces two axes: the main axis and the cross axis. By setting properties on the container and its child elements, you can control how they flow and align. 

To use CSS flexbox you need to define a flex container initially.

Flexbox layout is most appropriate to the components of an application, and small-scale layouts, while the Grid layout is intended for larger scale layouts.


display: 
---------
flex
inline-flex

ordering & orientation
---------------------------
flex-direction: row, row-reverse, column, column-reverse
flex-wrap: nowrap, wrap, wrap-reverse
flex-flow: wrap, no-wrap
order: -1/0/1

alignment
----------
justify-content: flex-start, flex-end, center, space-between, space-around, space-evenly
//based on cross axis
align-items: stretch, flex-start, flex-end, center, baseline, auto
align-self: auto, stretch, flex-start, flex-end, center, baseline
alint-content: flex-start, flex-end, center, space-between, space-around, stretch

flexibility
------------
flex-grow: 0/1; (no negative numbers)
flex-basis: 30%, 50%, content, auto
*/